from collections.abc import Iterable
from dataclasses import dataclass

from sqlalchemy.orm import Session

from app.schemas import JobOfferCreate
from app.services.job_offers import (
    DuplicateJobOfferError,
    create_job_offer,
)


@dataclass(frozen=True)
class ImportResult:
    found: int
    added: int
    duplicates: int
    errors: int
    added_offer_ids: tuple[int, ...] = ()


def import_job_offers(
    db: Session,
    offers: Iterable[JobOfferCreate],
) -> ImportResult:
    found = 0
    duplicates = 0
    errors = 0
    added_offer_ids: list[int] = []

    for offer in offers:
        found += 1

        try:
            created_offer = create_job_offer(
                db=db,
                data=offer,
            )
        except DuplicateJobOfferError:
            duplicates += 1
        except Exception:
            db.rollback()
            errors += 1
        else:
            added_offer_ids.append(
                created_offer.id,
            )

    return ImportResult(
        found=found,
        added=len(added_offer_ids),
        duplicates=duplicates,
        errors=errors,
        added_offer_ids=tuple(
            added_offer_ids,
        ),
    )